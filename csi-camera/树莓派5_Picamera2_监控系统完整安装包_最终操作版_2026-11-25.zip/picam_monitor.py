#!/usr/bin/python3
"""Simple Picamera2 web monitor for Raspberry Pi 5.

Features:
- MJPEG live view in a web browser
- Snapshot capture
- Manual recording
- Basic frame-difference motion-triggered recording
- 7-day automatic cleanup of old recordings and snapshots
- HTTP Basic Authentication (credentials supplied by systemd environment file)

This is a basic home-monitoring example, not an alarm/security-certified system.
"""

from __future__ import annotations

import os
import signal
import shutil
import threading
import time
from datetime import datetime, timedelta
from pathlib import Path
from functools import wraps
from hmac import compare_digest

import cv2
import numpy as np
from flask import Flask, Response, jsonify, request, send_from_directory
from picamera2 import Picamera2
from werkzeug.serving import make_server

# ------------------------- User-adjustable settings -------------------------
WIDTH = 1280
HEIGHT = 720
FPS = 10
JPEG_QUALITY = 75
MOTION_THRESHOLD_PERCENT = 2.0  # Increase to reduce false motion alerts.
MOTION_HOLD_SECONDS = 10        # Keep recording this long after the last motion.
RECORD_RETENTION_DAYS = 7
MIN_FREE_GB = 1.5               # Do not start a new recording if less space remains.
WEB_PORT = 8080
# ---------------------------------------------------------------------------

BASE_DIR = Path.home() / "PiCameraMonitor"
RECORD_DIR = BASE_DIR / "recordings"
SNAPSHOT_DIR = BASE_DIR / "snapshots"
RECORD_DIR.mkdir(parents=True, exist_ok=True)
SNAPSHOT_DIR.mkdir(parents=True, exist_ok=True)

WEB_USER = os.environ.get("CAMERA_USER", "viewer")
WEB_PASSWORD = os.environ.get("CAMERA_PASSWORD", "")
if not WEB_PASSWORD:
    raise SystemExit(
        "CAMERA_PASSWORD is empty. Create /home/camadmin/picam-monitor.env "
        "and set CAMERA_USER and CAMERA_PASSWORD before starting the service."
    )

app = Flask(__name__)
state_lock = threading.RLock()
stop_event = threading.Event()

camera = None
latest_jpeg: bytes | None = None
latest_bgr: np.ndarray | None = None
camera_error = ""
writer = None
writer_path: Path | None = None
manual_recording = False
motion_enabled = True
motion_now = False
last_motion_time = 0.0
last_changed_percent = 0.0
last_status_message = "Camera starting"


def require_login(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        auth = request.authorization
        valid = (
            auth is not None
            and compare_digest(auth.username or "", WEB_USER)
            and compare_digest(auth.password or "", WEB_PASSWORD)
        )
        if not valid:
            return Response(
                "Login required", 401,
                {"WWW-Authenticate": 'Basic realm="Raspberry Pi Camera Monitor"'},
            )
        return func(*args, **kwargs)
    return wrapper


@app.before_request
def authenticate_every_request():
    # Protect the page, video stream, API, snapshots and downloaded recordings.
    auth = request.authorization
    valid = (
        auth is not None
        and compare_digest(auth.username or "", WEB_USER)
        and compare_digest(auth.password or "", WEB_PASSWORD)
    )
    if not valid:
        return Response(
            "Login required", 401,
            {"WWW-Authenticate": 'Basic realm="Raspberry Pi Camera Monitor"'},
        )


def cleanup_old_files():
    cutoff = time.time() - RECORD_RETENTION_DAYS * 24 * 60 * 60
    for folder in (RECORD_DIR, SNAPSHOT_DIR):
        for path in folder.iterdir():
            try:
                if path.is_file() and path.stat().st_mtime < cutoff:
                    path.unlink()
            except OSError:
                pass


def start_video_writer() -> tuple[object | None, Path | None, str]:
    free_bytes = shutil.disk_usage(BASE_DIR).free
    if free_bytes < MIN_FREE_GB * 1024**3:
        return None, None, f"Recording not started: less than {MIN_FREE_GB:.1f} GB free."

    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    # Try MP4 first. If this OpenCV build does not support mp4v, try AVI/MJPEG.
    choices = [
        (RECORD_DIR / f"motion_{stamp}.mp4", "mp4v"),
        (RECORD_DIR / f"motion_{stamp}.avi", "MJPG"),
    ]
    for path, codec in choices:
        candidate = cv2.VideoWriter(
            str(path), cv2.VideoWriter_fourcc(*codec), FPS, (WIDTH, HEIGHT)
        )
        if candidate.isOpened():
            return candidate, path, f"Recording to {path.name}"
        candidate.release()
        try:
            path.unlink(missing_ok=True)
        except OSError:
            pass
    return None, None, "Could not open a video writer. Check OpenCV codec support."


def close_writer_locked():
    global writer, writer_path, last_status_message
    if writer is not None:
        try:
            writer.release()
        except Exception:
            pass
        finished_name = writer_path.name if writer_path else "recording"
        writer = None
        writer_path = None
        last_status_message = f"Recording saved: {finished_name}"


def camera_loop():
    global latest_jpeg, latest_bgr, camera_error, writer, writer_path
    global motion_now, last_motion_time, last_changed_percent, last_status_message

    previous_gray = None
    motion_hits = 0
    encode_params = [int(cv2.IMWRITE_JPEG_QUALITY), JPEG_QUALITY]
    last_cleanup = 0.0

    while not stop_event.is_set():
        try:
            rgb = camera.capture_array()
            bgr = cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR)

            # Use a small image for motion detection to reduce CPU load.
            small = cv2.resize(bgr, (320, 180), interpolation=cv2.INTER_AREA)
            gray = cv2.cvtColor(small, cv2.COLOR_BGR2GRAY)
            gray = cv2.GaussianBlur(gray, (21, 21), 0)

            changed_percent = 0.0
            detected = False
            if previous_gray is not None:
                delta = cv2.absdiff(previous_gray, gray)
                threshold = cv2.threshold(delta, 25, 255, cv2.THRESH_BINARY)[1]
                threshold = cv2.dilate(threshold, None, iterations=2)
                changed_percent = 100.0 * cv2.countNonZero(threshold) / threshold.size
                detected = changed_percent >= MOTION_THRESHOLD_PERCENT
            previous_gray = gray

            if detected:
                motion_hits = min(motion_hits + 1, 5)
            else:
                motion_hits = max(motion_hits - 1, 0)
            stable_motion = motion_hits >= 2
            now = time.time()
            if now - last_cleanup > 3600:
                cleanup_old_files()
                last_cleanup = now

            ok, encoded = cv2.imencode(".jpg", bgr, encode_params)
            if not ok:
                raise RuntimeError("Could not encode camera frame as JPEG")

            with state_lock:
                latest_bgr = bgr.copy()
                latest_jpeg = encoded.tobytes()
                last_changed_percent = changed_percent
                motion_now = stable_motion
                if stable_motion:
                    last_motion_time = now

                auto_recording = (
                    motion_enabled and last_motion_time > 0
                    and (now - last_motion_time) <= MOTION_HOLD_SECONDS
                )
                want_recording = manual_recording or auto_recording

                if want_recording and writer is None:
                    writer, writer_path, message = start_video_writer()
                    last_status_message = message
                elif not want_recording and writer is not None:
                    close_writer_locked()

                if writer is not None:
                    writer.write(bgr)

                camera_error = ""

        except Exception as exc:
            with state_lock:
                camera_error = str(exc)
                last_status_message = f"Camera error: {camera_error}"
            time.sleep(1)


def status_data():
    with state_lock:
        recording = writer is not None
        current_file = writer_path.name if writer_path else ""
        free_gb = shutil.disk_usage(BASE_DIR).free / (1024**3)
        return {
            "camera": "error" if camera_error else "running",
            "camera_error": camera_error,
            "recording": recording,
            "manual_recording": manual_recording,
            "motion_enabled": motion_enabled,
            "motion_detected": motion_now,
            "changed_percent": round(last_changed_percent, 2),
            "current_file": current_file,
            "free_gb": round(free_gb, 1),
            "message": last_status_message,
        }


@app.route("/")
def index():
    return """<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Raspberry Pi Camera Monitor</title>
<style>
body{font-family:Arial,sans-serif;background:#f3f5f7;color:#20252b;margin:0;padding:18px}
main{max-width:1000px;margin:auto;background:white;padding:18px;border-radius:12px;box-shadow:0 2px 12px #0001}
h1{font-size:25px;margin-top:4px}.video{width:100%;height:auto;background:#111;border-radius:8px}
.buttons{display:flex;flex-wrap:wrap;gap:10px;margin:14px 0}
button{border:0;border-radius:8px;padding:12px 16px;background:#245da8;color:white;font-size:15px;cursor:pointer}
button.secondary{background:#586574}button.warn{background:#ad3c35}
.status{background:#f0f3f6;padding:12px;border-radius:8px;line-height:1.65}
li{margin:7px 0}a{color:#1759a6}.small{color:#5b6570;font-size:13px}
</style></head>
<body><main>
<h1>Raspberry Pi Camera Monitor</h1>
<p class="small">Live view, snapshots, manual recording and motion-triggered recording.</p>
<img class="video" src="/stream" alt="Live camera stream">
<div class="buttons">
<button onclick="sendAction('/api/record/start')">Start manual recording</button>
<button class="warn" onclick="sendAction('/api/record/stop')">Stop manual recording</button>
<button class="secondary" onclick="sendAction('/api/snapshot')">Take snapshot</button>
<button class="secondary" onclick="sendAction('/api/motion/toggle')">Turn motion detection on/off</button>
</div>
<div class="status" id="status">Loading status…</div>
<h2>Recordings</h2><ul id="files"><li>Loading…</li></ul>
<h2>Snapshots</h2><ul id="shots"><li>Loading…</li></ul>
<p class="small">Motion detection is a simple image-change detector. Changes in lighting, shadows or moving objects can trigger it.</p>
</main>
<script>
async function sendAction(url){
  const r=await fetch(url,{method:'POST'}); const d=await r.json();
  if(!r.ok) alert(d.error||'Action failed'); await refresh();
}
async function refresh(){
  try{
    const s=await (await fetch('/api/status')).json();
    document.getElementById('status').innerHTML =
      'Camera: <b>'+s.camera+'</b><br>Recording: <b>'+(s.recording?'YES':'NO')+'</b>'+
      (s.current_file?(' ('+s.current_file+')'):'')+'<br>Motion detection: <b>'+(s.motion_enabled?'ON':'OFF')+'</b>'+
      '<br>Motion now: <b>'+(s.motion_detected?'YES':'NO')+'</b>'+
      '<br>Free storage: <b>'+s.free_gb+' GB</b><br>Status: '+s.message+
      (s.camera_error?('<br>Camera error: '+s.camera_error):'');
    const f=await (await fetch('/api/files')).json();
    document.getElementById('files').innerHTML=f.recordings.length?f.recordings.map(x=>'<li><a href="/recordings/'+encodeURIComponent(x)+'">'+x+'</a></li>').join(''):'<li>No recordings yet</li>';
    document.getElementById('shots').innerHTML=f.snapshots.length?f.snapshots.map(x=>'<li><a href="/snapshots/'+encodeURIComponent(x)+'">'+x+'</a></li>').join(''):'<li>No snapshots yet</li>';
  }catch(e){document.getElementById('status').textContent='Cannot read status: '+e;}
}
refresh(); setInterval(refresh,4000);
</script></body></html>"""


@app.route("/stream")
def stream():
    def generate():
        while not stop_event.is_set():
            with state_lock:
                frame = latest_jpeg
            if frame:
                yield (b"--frame\r\nContent-Type: image/jpeg\r\n\r\n" + frame + b"\r\n")
            time.sleep(0.08)
    return Response(generate(), mimetype="multipart/x-mixed-replace; boundary=frame")


@app.route("/api/status")
def api_status():
    return jsonify(status_data())


@app.route("/api/files")
def api_files():
    recordings = sorted(
        [p.name for p in RECORD_DIR.iterdir() if p.is_file()], reverse=True
    )[:30]
    snapshots = sorted(
        [p.name for p in SNAPSHOT_DIR.iterdir() if p.is_file()], reverse=True
    )[:30]
    return jsonify({"recordings": recordings, "snapshots": snapshots})


@app.route("/api/record/start", methods=["POST"])
def api_record_start():
    global manual_recording
    with state_lock:
        manual_recording = True
    return jsonify({"ok": True, "message": "Manual recording requested"})


@app.route("/api/record/stop", methods=["POST"])
def api_record_stop():
    global manual_recording
    with state_lock:
        manual_recording = False
    return jsonify({"ok": True, "message": "Manual recording stop requested"})


@app.route("/api/motion/toggle", methods=["POST"])
def api_motion_toggle():
    global motion_enabled
    with state_lock:
        motion_enabled = not motion_enabled
        enabled = motion_enabled
    return jsonify({"ok": True, "motion_enabled": enabled})


@app.route("/api/snapshot", methods=["POST"])
def api_snapshot():
    with state_lock:
        frame = None if latest_bgr is None else latest_bgr.copy()
    if frame is None:
        return jsonify({"ok": False, "error": "Camera frame is not ready"}), 503
    filename = datetime.now().strftime("snapshot_%Y%m%d_%H%M%S.jpg")
    path = SNAPSHOT_DIR / filename
    if not cv2.imwrite(str(path), frame):
        return jsonify({"ok": False, "error": "Could not save snapshot"}), 500
    return jsonify({"ok": True, "file": filename})


@app.route("/recordings/<path:filename>")
def download_recording(filename):
    return send_from_directory(RECORD_DIR, filename, as_attachment=False)


@app.route("/snapshots/<path:filename>")
def view_snapshot(filename):
    return send_from_directory(SNAPSHOT_DIR, filename, as_attachment=False)


def main():
    global camera
    cleanup_old_files()
    print("Starting Picamera2. Make sure the CSI camera is connected.", flush=True)
    camera = Picamera2()
    config = camera.create_video_configuration(
        main={"size": (WIDTH, HEIGHT), "format": "RGB888"},
        controls={"FrameRate": FPS},
    )
    camera.configure(config)
    camera.start()

    worker = threading.Thread(target=camera_loop, name="camera-capture", daemon=True)
    worker.start()

    server = make_server("0.0.0.0", WEB_PORT, app, threaded=True)

    def request_shutdown(signum, frame):
        stop_event.set()
        threading.Thread(target=server.shutdown, daemon=True).start()

    signal.signal(signal.SIGTERM, request_shutdown)
    signal.signal(signal.SIGINT, request_shutdown)

    print(f"Web monitor listening on http://0.0.0.0:{WEB_PORT}", flush=True)
    try:
        server.serve_forever()
    finally:
        stop_event.set()
        worker.join(timeout=5)
        with state_lock:
            close_writer_locked()
        try:
            camera.stop()
            camera.close()
        except Exception:
            pass
        server.server_close()


if __name__ == "__main__":
    main()
